<h1 align="center">Numlist Gen 📳 & Debounce Opérateur ✔️</h1>

###

<h2 align="left">A propos du programme ⭐</h2>

###

<p align="left">✨ Génère des numéros +33 (désactivable)<br>📚 Check opérateur (au choix).<br>🎯 Génération rapide.<br>🎲 Numéros valides.<br>📜 Enregistre les numéros dans un dossier au choix.</p>

###

<h1 align="center">Guide 🔌</h1>

###

<p align="left">1. Ouvrir le setup.bat, les modules s'installerons.<br>2. Ouvrir le NLGEN.py.<br>3. Enjoy !</p>

###

<div align="center">
  <img height="200" src="https://media.discordapp.net/attachments/996490118229671967/1109057615033532506/image.png"  />
</div>

###
